EXTRA_DEFINES += USE_X11=ON
host_build {
    QT_CPU_FEATURES.x86_64 = abm adx aes avx avx2 bmi bmi2 cx16 f16c fma fsgsbase lzcnt mmx movbe pclmul popcnt prfchw rdpid rdrnd rdseed sha sse sse2 sse3 ssse3 sse4a sse4.1 sse4.2 sse4
} else {
    QT_CPU_FEATURES.x86_64 = abm adx aes avx avx2 bmi bmi2 cx16 f16c fma fsgsbase lzcnt mmx movbe pclmul popcnt prfchw rdpid rdrnd rdseed sha sse sse2 sse3 ssse3 sse4a sse4.1 sse4.2 sse4
}
QT.global_private.enabled_features = sse2 alloca_h alloca avx2 dbus dbus-linked dlopen gui libudev network posix_fallocate reduce_exports reduce_relocations relocatable sql system-zlib testlib widgets xml zstd
QT.global_private.disabled_features = alloca_malloc_h android-style-assets private_tests gc_binaries intelcet release_tools stack-protector-strong
PKG_CONFIG_EXECUTABLE = $$[QT_HOST_PREFIX/get]/usr/bin/pkg-config
QMAKE_LIBS_DBUS = -ldbus-1
QMAKE_INCDIR_DBUS = $$[QT_SYSROOT]/usr/include/dbus-1.0 $$[QT_SYSROOT]/usr/lib/dbus-1.0/include
QMAKE_LIBS_LIBDL = 
QMAKE_LIBS_LIBUDEV = -ludev
QT_COORD_TYPE = double
QMAKE_LIBS_ZLIB = -lz
QMAKE_LIBS_ZSTD = -lzstd
CONFIG -= precompile_header
CONFIG += cross_compile sse2 aesni sse3 ssse3 sse4_1 sse4_2 avx avx2 avx512f avx512bw avx512cd avx512dq avx512ifma avx512vbmi avx512vl compile_examples enable_new_dtags f16c largefile rdrnd rdseed shani silent x86SimdAlways
QT_BUILD_PARTS += libs tests tools
QT_HOST_CFLAGS_DBUS += -I$$[QT_SYSROOT]/usr/include/dbus-1.0 -I$$[QT_SYSROOT]/usr/lib/dbus-1.0/include
HOST_QT_TOOLS = $$[QT_HOST_PREFIX/get]/usr/bin
