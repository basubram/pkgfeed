/*
 * oFono - Open Source Telephony
 * Copyright (C) 2008-2011  Intel Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */

#ifndef __OFONO_VERSION_H
#define __OFONO_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define OFONO_VERSION	"2.19"

#ifdef __cplusplus
}
#endif

#endif /* __OFONO_VERSION_H */
