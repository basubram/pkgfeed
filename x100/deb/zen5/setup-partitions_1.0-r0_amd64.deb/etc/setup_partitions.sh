#!/bin/bash
LOGFILE="/var/log/setup_partitions.log"
exec > >(tee -a "$LOGFILE") 2>&1

echo "[$(date)] Starting nvme0n1p3 setup..."

# Ensure we are running as root
if [[ $(id -u) -ne 0 ]]; then
    echo "[$(date)] ERROR: This script must be run as root!"
    exit 1
fi

DISK="/dev/nvme0n1"
NEW_PART="${DISK}p3"

# Create new partition (starts after nvme0n1p2 at 70%)
echo "[$(date)] Creating $NEW_PART..."
parted -s "$DISK" mkpart primary ext4 70% 100%
if [ $? -ne 0 ]; then
    echo "[$(date)] ERROR: Failed to create $NEW_PART."
    exit 1
fi

# Format the new partition
echo "[$(date)] Formatting $NEW_PART as ext4..."
mkfs.ext4 "$NEW_PART"
if [ $? -ne 0 ]; then
    echo "[$(date)] ERROR: Failed to format $NEW_PART."
    exit 1
fi

# Create mount point and mount the partition
MOUNT_POINT="/run/media/nvme0n1p3"
mkdir -p "$MOUNT_POINT"
mount "$NEW_PART" "$MOUNT_POINT"
if [ $? -ne 0 ]; then
    echo "[$(date)] ERROR: Failed to mount $NEW_PART at $MOUNT_POINT."
    exit 1
fi

echo "[$(date)] nvme0n1p3 setup completed successfully!"
