// AMD sample out-of-tree kernel module (build-time .ko reference).
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

static int __init amd_hello_init(void)
{
        pr_info("amd_hello: loaded (AMD out-of-tree sample module)\n");
        return 0;
}

static void __exit amd_hello_exit(void)
{
        pr_info("amd_hello: unloaded\n");
}

module_init(amd_hello_init);
module_exit(amd_hello_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AMD");
MODULE_DESCRIPTION("AMD sample out-of-tree kernel module");
