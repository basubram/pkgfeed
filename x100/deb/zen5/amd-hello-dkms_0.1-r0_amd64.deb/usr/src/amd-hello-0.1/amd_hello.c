// AMD out-of-tree DKMS sample driver. Deliberately uses several kernel
// subsystems (module params, procfs/seq_file, a timer, atomics) so a
// successful build/load actually exercises the kernel headers and APIs.
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/moduleparam.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/timer.h>
#include <linux/jiffies.h>
#include <linux/atomic.h>
#include <linux/version.h>

#define AMD_HELLO_PROC "amd_hello"

static char *who = "AMD";
module_param(who, charp, 0444);
MODULE_PARM_DESC(who, "name shown in /proc/amd_hello");

static int times = 3;
module_param(times, int, 0444);
MODULE_PARM_DESC(times, "number of greeting lines in /proc/amd_hello");

static atomic_t reads = ATOMIC_INIT(0);
static atomic_t ticks = ATOMIC_INIT(0);
static unsigned long load_jiffies;
static struct timer_list amd_timer;
static struct proc_dir_entry *amd_entry;

static void amd_timer_fn(struct timer_list *t)
{
	atomic_inc(&ticks);
	mod_timer(&amd_timer, jiffies + msecs_to_jiffies(1000));
}

static int amd_hello_show(struct seq_file *m, void *v)
{
	int i, n = atomic_inc_return(&reads);

	seq_printf(m, "amd_hello: out-of-tree DKMS sample\n");
	seq_printf(m, "kernel    : %d.%d.%d\n",
		   (LINUX_VERSION_CODE >> 16) & 0xff,
		   (LINUX_VERSION_CODE >> 8) & 0xff,
		   LINUX_VERSION_CODE & 0xff);
	seq_printf(m, "who       : %s\n", who);
	seq_printf(m, "reads     : %d\n", n);
	seq_printf(m, "ticks(1s) : %d\n", atomic_read(&ticks));
	seq_printf(m, "uptime_ms : %u\n", jiffies_to_msecs(jiffies - load_jiffies));
	for (i = 0; i < times; i++)
		seq_printf(m, "hello %s #%d\n", who, i + 1);
	return 0;
}

static int amd_hello_open(struct inode *inode, struct file *file)
{
	return single_open(file, amd_hello_show, NULL);
}

static const struct proc_ops amd_hello_proc_ops = {
	.proc_open    = amd_hello_open,
	.proc_read    = seq_read,
	.proc_lseek   = seq_lseek,
	.proc_release = single_release,
};

static int __init amd_hello_init(void)
{
	load_jiffies = jiffies;

	amd_entry = proc_create(AMD_HELLO_PROC, 0444, NULL, &amd_hello_proc_ops);
	if (!amd_entry) {
		pr_err("amd_hello: cannot create /proc/%s\n", AMD_HELLO_PROC);
		return -ENOMEM;
	}

	timer_setup(&amd_timer, amd_timer_fn, 0);
	mod_timer(&amd_timer, jiffies + msecs_to_jiffies(1000));

	pr_info("amd_hello: loaded (who=%s times=%d); read /proc/%s\n",
		who, times, AMD_HELLO_PROC);
	return 0;
}

static void __exit amd_hello_exit(void)
{
	timer_delete_sync(&amd_timer);
	proc_remove(amd_entry);
	pr_info("amd_hello: unloaded (%d reads, %d ticks)\n",
		atomic_read(&reads), atomic_read(&ticks));
}

module_init(amd_hello_init);
module_exit(amd_hello_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AMD");
MODULE_DESCRIPTION("AMD OOT DKMS sample: procfs + params + timer + atomics");
MODULE_VERSION("0.1");
