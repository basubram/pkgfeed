#!/bin/bash

#############################################################################################################################
# You can flash an already downloaded .wic image or download a .wic.bz2
# image from any HTTP(S) server (pass either the .wic file or the URL
# as an argument to this script).
#############################################################################################################################
# Exit immediately if a command exits with a non-zero status
set -e
# Function to log info messages
log_info() {
    echo "[INFO] $1"
}

# Function to check if input is a URL
is_url() {
    [[ "$1" =~ ^https?:// ]]
}

# Input argument: can be a URL or a file name in /home
INPUT=$1

if [ -z "$INPUT" ]; then
    echo "Usage: $0 <URL or local .wic/.wic.bz2 file in /home>"
    exit 1
fi

# Step 1: Determine file path and names

if is_url "$INPUT"; then
    # Handle URL case
    DOWNLOAD_URL="$INPUT"
    FILE_NAME=$(basename "$DOWNLOAD_URL")
    FILE_PATH="./$FILE_NAME"
    
    # Step 2: Download the file if not already available
    if [ -f "$FILE_PATH" ]; then
        log_info "File already downloaded: $FILE_NAME"
    else
        log_info "Downloading $DOWNLOAD_URL"
        wget -O "$FILE_PATH" "$DOWNLOAD_URL"
    fi
else
    # Handle local file case
    FILE_PATH="$INPUT"
    FILE_NAME=$(basename "$FILE_PATH")

    if [ ! -f "$FILE_PATH" ]; then
        echo "[ERROR] File not found: $FILE_PATH"
        exit 1
    fi

    log_info "Using local file: $FILE_PATH"
fi

# Step 3: Extract the file if it's a .bz2
if [[ "$FILE_PATH" == *.bz2 ]]; then
    EXTRACTED_FILE="${FILE_PATH%.bz2}"
    if [ -f "$EXTRACTED_FILE" ]; then
        log_info "File already extracted: $EXTRACTED_FILE"
    else
        log_info "Extracting $FILE_NAME"
        bzip2 -dk "$FILE_PATH"
    fi
else
    EXTRACTED_FILE="$FILE_PATH"
    log_info "File is not compressed, proceeding with: $EXTRACTED_FILE"
fi

# Step 4: Unmount each folder under /run/media
log_info "Unmounting all folders under /run/media"
for folder in /run/media/*; do
    if mountpoint -q "$folder"; then
        log_info "Unmounting $folder"
        umount "$folder"
    fi
done

# Step 5: Flash the image to /dev/nvme0n1
log_info "Flashing the image to /dev/nvme0n1"
dd if="$EXTRACTED_FILE" of=/dev/nvme0n1 bs=4M status=progress

# Step 6: Sync the disk
log_info "Syncing the disk"
sync

# Step 7: Mount the partition /dev/nvme0n1p2
log_info "Mounting /dev/nvme0n1p2 to /run/media/rootfs-nvme0n1p2"
mkdir -p /run/media/rootfs-nvme0n1p2
mount /dev/nvme0n1p2 /run/media/rootfs-nvme0n1p2/

# Step 8: Update fstab file
log_info "Updating fstab file to change sda1 to nvme0n1p1"
sed -i 's/sda1/nvme0n1p1/g' /run/media/rootfs-nvme0n1p2/etc/fstab

# Step 9: Sync again
log_info "Syncing again"
sync

#Unmount the partition /dev/nvme0n1p2
log_info "Unmounting /run/media/rootfs-nvme0n1p2"
umount /run/media/rootfs-nvme0n1p2

# Step 10: Resize the partition
log_info "Resizing partition 2 to 100% using parted"
parted /dev/nvme0n1 <<EOF
resizepart 2 100%
quit
EOF

# Step 11: Check and resize the filesystem
log_info "Running e2fsck on /dev/nvme0n1p2"
e2fsck -f /dev/nvme0n1p2

log_info "Resizing filesystem on /dev/nvme0n1p2"
resize2fs /dev/nvme0n1p2

# Step 12: Final sync
log_info "Final sync"
sync

log_info "Process completed successfully"

