export QT_QPA_FONTDIR="/usr/share/fonts/ttf"
export QT_QPA_PLATFORM="xcb"
